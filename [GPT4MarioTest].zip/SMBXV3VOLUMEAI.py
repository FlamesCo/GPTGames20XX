import os
import pygame
import sys

# Initialize Pygame
pygame.init()

# Set screen size and caption
screen_width, screen_height = 800, 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Mario 1-1")

# Create clock object
clock = pygame.time.Clock()

# Get the directory of this script
script_dir = os.path.dirname(os.path.abspath(__file__))

# Load background and Mario images
background_image = pygame.image.load(os.path.join(script_dir, "background.png"))
mario_image = pygame.image.load(os.path.join(script_dir, "mario.png"))

# Create a Rect object for Mario
mario = pygame.Rect(100, 400, 32, 32)

# Initialize Mario's speed and state variables
mario_speed_x = 0
mario_speed_y = 0
on_ground = True
gravity = 1
max_speed = 10

# Main game loop
while True:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                if mario_speed_x > -max_speed:
                    mario_speed_x -= 1
            if event.key == pygame.K_RIGHT:
                if mario_speed_x < max_speed:
                    mario_speed_x += 1
            if event.key == pygame.K_SPACE and on_ground:
                mario_speed_y = -20
                on_ground = False

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                if mario_speed_x > 0:
                    mario_speed_x -= 1
                if mario_speed_x < 0:
                    mario_speed_x += 1

    # Physics and collisions
    mario_speed_y += gravity
    mario.y += mario_speed_y
    on_ground = False

    # Check for collisions with the ground (temporary)
    if mario.y >= screen_height - 32:
        mario.y = screen_height - 32
        on_ground = True

    mario.x += mario_speed_x

    # Clear screen and draw background
    screen.fill((0, 0, 0))
    screen.blit(background_image, (0, 0))

    # Draw Mario
    screen.blit(mario_image, mario)

    # Update screen
    pygame.display.flip()
    clock.tick(60)
